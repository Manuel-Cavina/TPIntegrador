package com.tpi.logistica.servicio_camiones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioCamionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
